/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flowersystems;

import java.io.File;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;

/**
 *
 * @author Vannchinhkuy
 */
public class dashboardControll implements Initializable{
    
    @FXML
    private Button AvailableFlowersBtn;

    @FXML
    private Label AvailableFolwers;

    @FXML
    private TextField Available_FlowerID;

    @FXML
    private TextField Available_FlowerName;

    @FXML
    private TextField Available_Price;

    @FXML
    private ComboBox<?> Available_Status;

    @FXML
    private Button Available_addBtn;

    @FXML
    private Button Available_clearBtn;

    @FXML
    private TableColumn<flowersData, String> Available_col_Status;

    @FXML
    private TableColumn<flowersData, String> Available_col_flowerID;

    @FXML
    private TableColumn<flowersData, String> Available_col_flowerName;

    @FXML
    private TableColumn<flowersData, String> Available_col_price;

    @FXML
    private Button Available_deleteBtn;

    @FXML
    private TextField Available_search;

    @FXML
    private TableView<flowersData> Available_tableView;

    @FXML
    private Button Available_updateBtn;

    @FXML
    private Button PurchaseBtn;

    @FXML
    private Button Purchase_AddtoCartBtn;

    @FXML
    private TableView<customerData> Purchase_TableView;

      @FXML
    private TableColumn<customerData, String> Purchase_col_FlowerName;

    @FXML
    private TableColumn<customerData, String> Purchase_col_Price;

    @FXML
    private TableColumn<customerData, String> Purchase_col_Quantity;

    @FXML
    private TableColumn<customerData, String> Purchase_col_flowerID;

    @FXML
    private ComboBox<?> Purchase_flowerID;

    @FXML
    private ComboBox<?> Purchase_flowerName;

    @FXML
    private Button Purchase_payBtn;

    @FXML
    private Spinner<Integer> Purchase_quantity;

    @FXML
    private Label Purchase_total;

    @FXML
    private Label TotalCustomer;

    @FXML
    private Label TotalIncome;

    @FXML
    private AnchorPane available_form;

    @FXML
    private Button close;

    @FXML
    private Button homeBtn;

    @FXML
    private AnchorPane home_form;

    @FXML
    private BarChart<?, ?> home_tableView;

    @FXML
    private ImageView imageimport;

    @FXML
    private Button importBtn;

    @FXML
    private Button logoutBtn;

    @FXML
    private AnchorPane main_form;

    @FXML
    private Button minus;

    @FXML
    private AnchorPane purchase_form;

    @FXML
    private Label username;
    
    @FXML
    private AnchorPane top_form;
    
    private double x = 0;
    private double y = 0;
    private Image image;

    // DATABASE TOOL
    private Connection connect;
    private PreparedStatement prepare;
    private Statement statement;
    private ResultSet result;
    
   public void availableFlowerAdd() {
       
       String sql = "INSERT INTO flowers (flower_id, name, status, price, image, date) VALUES (?, ?, ?, ?, ?, ?)";

       
       connect = database.connectionDb();
       
       try{
           Alert alert;
           
           if(Available_FlowerID.getText().isEmpty() || Available_FlowerName.getText().isEmpty()
                   || Available_FlowerName.getText().isEmpty()
                   || (String)Available_Status.getSelectionModel().getSelectedItem() == null
                   || Available_Price.getText().isEmpty()
                   || getData.path == null || getData.path == "") {
               
               alert = new Alert(AlertType.ERROR);
               alert.setTitle("Error Message");
               alert.setHeaderText(null);
               alert.setContentText("Please fill all blank fields");
               alert.showAndWait();
            
               
               
           }else{
               
               String checkData = "SELECT flower_id FROM flowers WHERE flower_id  = '"
                       + Available_FlowerID.getText().isEmpty() + "'";
               
               statement = connect.createStatement();
               result = statement.executeQuery(checkData);
               
               if(result.next()) {
                   
                    alert = new Alert(AlertType.ERROR);
                    alert.setTitle("Error Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Flower ID :" + Available_FlowerID.getText() + " was already exist!");
                    alert.showAndWait();
                   
               }else{
                    prepare = connect.prepareStatement(sql); 
                    prepare.setString(1, Available_FlowerID.getText());
                    prepare.setString(2, Available_FlowerName.getText());
                    prepare.setString(3, (String)Available_Status.getSelectionModel().getSelectedItem());
                    prepare.setString(4, Available_Price.getText());

                    String uri = getData.path;
                    uri = uri.replace("\\", "\\\\");
                    prepare.setString(5, uri);

                    Date date = new Date();
                    java.sql.Date sqlDate = new java.sql.Date(date.getTime());

                    prepare.setString(6, String.valueOf(sqlDate));
                    
                    prepare.executeUpdate();
                    
                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Succesfully for Add " + Available_FlowerName.getText());
                    alert.showAndWait();
                    
                    
                    // when insert full is availableFlowerChaer run;
                    availableFlowersChear();
                    
                    availableFlowerShowListData();//ShowListData when new insert the table
                    
               }
               
//                prepare = connect.prepareStatement(sql);
                
           }
       }catch(Exception e) {e.printStackTrace();}
   }
    
   public void availableFlowersUpdate() {
       
       String uri = getData.path;
       uri = uri.replace("\\", "\\\\");
       
//       String sql = "UPDATE movie SET movieTitle = '" + addMovies_MovieTitle.getText()
//                + "', genre = '" + addMovies_genre.getText()
//                + "', duration = '" + addMovies_duration.getText()
//                + "', image = '" + uri
//                + "', date = '" + addMovies_date.getValue() 
//                + "' WHERE id = '" + String.valueOf(getData.movieId) + "'";
       
       String sql ="UPDATE flowers SET name = '" + Available_FlowerName.getText()
               + "' , status = '" + Available_Status.getSelectionModel().getSelectedItem()
               + "', price = '" + Available_Price.getText()
               + "', image = '" + uri 
               + "' WHERE flower_id = '" + Available_FlowerID.getText() + "'";
       connect = database.connectionDb();
       
       try{
           
           statement = connect.createStatement();
           Alert alert;
           
           if(Available_FlowerID.getText().isEmpty() 
                   || Available_FlowerName.getText().isEmpty()
                   || Available_FlowerName.getText().isEmpty()
                   || (String)Available_Status.getSelectionModel().getSelectedItem() == null
                   || imageimport.getImage() == null
                   || Available_Price.getText().isEmpty()
                   ) {
               
               alert = new Alert(AlertType.ERROR);
               alert.setTitle("Error Message");
               alert.setHeaderText(null);
               alert.setContentText("Please fill all blank fields");
               alert.showAndWait();
           }else{
               
               alert = new Alert(AlertType.CONFIRMATION);
               alert.setTitle("Confirmation Message");
               alert.setHeaderText(null);
               alert.setContentText("Are you sure to Update Flower Id :" + Available_FlowerID.getText() + "?");
               Optional<ButtonType> option = alert.showAndWait();
               
               if(option.get().equals(ButtonType.OK)) {
                   
                   
                   statement.executeUpdate(sql);
                   
                   // when insert full is availableFlowerChaer run;
                    availableFlowersChear();
                    
                    availableFlowerShowListData();//ShowListData when new insert the table
                   
                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Informmation Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Successfully Updated!!" + Available_FlowerName.getText());
                    alert.showAndWait();

               }
           }
           
       }catch(Exception e) {e.printStackTrace();}
       
   }
   
   public void availableFlowersSearch(){
        
        FilteredList<flowersData> filter = new FilteredList<>(availableFlowersList,e -> true);
        
        Available_search.textProperty().addListener((observable, oldValue, newValue) ->{
        
           filter.setPredicate(PrediateFlowerData->{
               
               if(newValue.isEmpty() || newValue == null) {
                   return true;
               }
               
               String searchkey = newValue.toLowerCase();
               
               if(PrediateFlowerData.getFlowerId().toString().contains(searchkey)){
                   return true;
               }else if(PrediateFlowerData.getName().toLowerCase().contains(searchkey)){
                   return true;
               }else if(PrediateFlowerData.getStatus().toLowerCase().contains(searchkey)){
                   return true;
               }else if(PrediateFlowerData.getPrice().toString().contains(searchkey)){
                   return true;
               }
               return false;
               
           });
            
        });
               SortedList<flowersData> sortList = new SortedList<>(filter);
               
               sortList.comparatorProperty().bind(Available_tableView.comparatorProperty());
               Available_tableView.setItems(sortList);
        
    }
   
   public void availableFlowersDelete() {
       
       String sql = "DELETE FROM flowers WHERE flower_id = '"
               + Available_FlowerID.getText()+ "'";
       
       connect = database.connectionDb();
       
       try{
           
           statement = connect.createStatement();
           Alert alert;
           if(Available_FlowerID.getText().isEmpty() || Available_FlowerName.getText().isEmpty()
                   || Available_FlowerName.getText().isEmpty()
                   || (String)Available_Status.getSelectionModel().getSelectedItem() == null
                   || Available_Price.getText().isEmpty()
                   || getData.path == null || getData.path == "") {
               
               alert = new Alert(AlertType.ERROR);
               alert.setTitle("Error Message");
               alert.setHeaderText(null);
               alert.setContentText("Please fill all blank fields");
               alert.showAndWait();
           }else{
               
               alert = new Alert(AlertType.CONFIRMATION);
               alert.setTitle("Confirmation Message");
               alert.setHeaderText(null);
               alert.setContentText("Are you sure to Delete Flower Id :" + Available_FlowerID.getText() + "?");
               Optional<ButtonType> option = alert.showAndWait();
               
               if(option.get().equals(ButtonType.OK)) {
                   
                   statement.executeUpdate(sql);
                   
                   // when insert full is availableFlowerChaer run;
                    availableFlowersChear();
                    
                    availableFlowerShowListData();//ShowListData when new insert the table
                   
                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Informmation Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Successfully Deleted!!");
                    alert.showAndWait();

               }
           }
           
       }catch(Exception e) {e.printStackTrace();}
       
   }
   
   public void availableFlowerSelect() {
       
       flowersData flower = Available_tableView.getSelectionModel().getSelectedItem();
       int num = Available_tableView.getSelectionModel().getSelectedIndex();
       
       if((num - 1)< - 1) return;
       
        Available_FlowerID.setText(String.valueOf(flower.getFlowerId()));
        Available_FlowerName.setText(flower.getName());
        Available_Price.setText(String.valueOf((flower.getPrice())));
       
       getData.path = flower.getImage();
       
       String uri = "file:" + flower.getImage();
       
//       getData.path = flower.getImage();
       image = new Image(uri,126 , 181, false, true);
       imageimport.setImage(image);
        
   }
   
   String listStatus[] = {"Available", "Not Available"};
   public void availableFlowersStatus() {
      
       List<String> listS = new ArrayList<>();
       
       for(String data : listStatus){
           listS.add(data);
       }
       ObservableList listData = FXCollections.observableArrayList(listS);
       Available_Status.setItems(listData);
       
       
   }
  
    public void availableFlowersChear() {
        Available_FlowerID.setText("");
        Available_FlowerName.setText("");
        Available_Status.getSelectionModel().clearSelection();
        Available_Price.setText("");
        getData.path = "";
        
        imageimport.setImage(null);
        
        
    }
   
    public void availableFlowersInsertImage() {
        
        FileChooser open = new FileChooser();
        open.setTitle("Open Image File");
        open.getExtensionFilters().add(new ExtensionFilter("Image File", "*jpg", "*png"));
        
        File file = open.showOpenDialog(main_form.getScene().getWindow());
        
        if (file != null) {

            image = new Image(file.toURI().toString(), 126, 145, false, true);

            imageimport.setImage(image);
            getData.path = file.getAbsolutePath();
        }
        
    }
    
    public void close() {
        System.exit(0);
    }

    public void minimize() {
        Stage stage = (Stage) top_form.getScene().getWindow();
        stage.setIconified(true);
    }
    
    public void logout() {

        try {

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation Message");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure you want to logout?");

            Optional<ButtonType> option = alert.showAndWait();
            if (option.get().equals(ButtonType.OK)) {

                logoutBtn.getScene().getWindow().hide();
                // BACK TO LOGIN FORM
                Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
                Stage stage = new Stage();
                Scene scene = new Scene(root);

                stage.setScene(scene);
                stage.show();

                root.setOnMousePressed((MouseEvent event) -> {
                    x = event.getSceneX();
                    y = event.getSceneY();
                });

                root.setOnMouseDragged((MouseEvent event) -> {
                    stage.setX(event.getScreenX() - x);
                    stage.setY(event.getScreenY() - y);

                    stage.setOpacity(.8);
                });

                root.setOnMouseReleased((MouseEvent event) -> {
                    stage.setOpacity(1);
                });

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public ObservableList<flowersData> availableFlowersListData() {
        
        ObservableList<flowersData> listData = FXCollections.observableArrayList();
     
        String sql = "SELECT * FROM flowers";
        
        connect = database.connectionDb();
        
        try{
            
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();
            
            flowersData flower;
            
            while(result.next()) {
                //                                   Table flowers(flower_id)
                flower = new flowersData(result.getInt("flower_id")
                , result.getString("name")
                , result.getString("status")
                , result.getDouble("price")
                , result.getString("image")
                , result.getDate("date"));
                
                listData.add(flower);
                
            }
            
        }catch(Exception e) {e.printStackTrace();}
        return listData;
    }
    private ObservableList<flowersData> availableFlowersList;
    public void availableFlowerShowListData() {
        availableFlowersList = availableFlowersListData();
        
        Available_col_flowerID.setCellValueFactory(new PropertyValueFactory<>("flowerId"));
        Available_col_flowerName.setCellValueFactory(new PropertyValueFactory<>("name"));
        Available_col_Status.setCellValueFactory(new PropertyValueFactory<>("status"));
        Available_col_price.setCellValueFactory(new PropertyValueFactory<>("price"));

        Available_tableView.setItems(availableFlowersList);
        
    }

    public ObservableList<customerData> purchaseListData() {
        purchaseCustomerId();
        
        ObservableList<customerData> listData = FXCollections.observableArrayList();
        
        String sql = "SELECT * FROM customer WHERE customer_id = '"+customerId+"'";
        
        connect = database.connectionDb();
        
        try{
            
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();
            
            customerData customer;
            
            while(result.next()) {
                customer = new customerData(result.getInt("customer_id")
                        , result.getInt("flower_id")
                        , result.getString("name")
                        , result.getInt("quantity")
                        , result.getDouble("price")
                        , result.getDate("date"));
                
                listData.add(customer);
            }
            
        }catch(Exception e) {e.printStackTrace();}
        return listData;
    }
    
    private ObservableList<customerData> purchaseListD;
    public void purchaseShowListData() {
        purchaseListD = purchaseListData();
        
        Purchase_col_flowerID.setCellValueFactory(new PropertyValueFactory<>("flowerId"));
        Purchase_col_FlowerName.setCellValueFactory(new PropertyValueFactory<>("name"));
        Purchase_col_Quantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        Purchase_col_Price.setCellValueFactory(new PropertyValueFactory<>("price"));
    
        Purchase_TableView.setItems(purchaseListD);
    }
   
    private int customerId;
    public void purchaseCustomerId() {
        
        String sql = "SELECT MAX(customer_id) FROM customer";
        
        connect = database.connectionDb();
        
        try{
            
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();
            
            if(result.next()) {
                customerId = result.getInt("MAX(customer_id)");
            }
            
            int countData = 0;
            
            String checkInfo = "SELECT MAX(customer_id) FROM customer_information";
            
            prepare = connect.prepareStatement(checkInfo);
            result = prepare.executeQuery();
            
            if(result.next()) {
                countData = result.getInt("MAX(customer_id)");
            }
            
            if(customerId == 0) {
                customerId += 1;
            }else if(customerId == countData) {
                customerId = countData + 1;
            }
            
        }catch(Exception e) {e.printStackTrace();}
    }
    
    public void purchaseAddToCart() {
        purchaseCustomerId();
        String sql = "INSERT INTO customer (customer_id, flower_id, name, quantity, price, date)"
                + "VALUES(?,?,?,?,?,?)";
        
        connect = database.connectionDb();
        
        try{
            
            Alert alert;
            
            if(Purchase_flowerID.getSelectionModel().getSelectedItem() == null
                    || Purchase_flowerName.getSelectionModel().getSelectedItem() == null
                    || qty == 0){
                
                alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Please choose the product first");
                alert.showAndWait();
            }else{
                double priceData = 0;
                double totalPrice;

                String checkPrice = "SELECT name, price FROM flowers WHERE name = '"
                        + Purchase_flowerName.getSelectionModel().getSelectedItem() + "'";

                statement = connect.createStatement();
                result = statement.executeQuery(checkPrice);

                if(result.next()) {
                    priceData = result.getDouble("price");
                }

                prepare = connect.prepareStatement(sql);
                prepare.setString(1, String.valueOf(customerId));
                prepare.setInt(2, (Integer)Purchase_flowerID.getSelectionModel().getSelectedItem());
                prepare.setString(3, (String)Purchase_flowerName.getSelectionModel().getSelectedItem());
                prepare.setString(4, String.valueOf(qty));

                totalPrice = (priceData * qty);

                prepare.setString(5, String.valueOf(totalPrice));

                Date date = new Date();
                java.sql.Date sqlDate = new java.sql.Date(date.getTime());

                prepare.setString(6, String.valueOf(sqlDate));
                
                prepare.executeUpdate();
                purchaseShowListData();
                purchaseDisplayTotal();

            }
            

        }catch(Exception e) {e.printStackTrace();}
    }
    
    public void displayUsername() {
        username.setText(getData.username);
//          String user = getData.username;
//          username.setText(user.substring(0, 1).toUpperCase() + user.substring(1));
    }
    
    public void homeAF() {
        
        String sql = "SELECT COUNT(id) FROM flowers WHERE status = 'Available'";
        
        connect = database.connectionDb();
        
        try{
            
            int countAF = 0;
            statement = connect.createStatement();
            result = statement.executeQuery(sql);
            
            if(result.next()) {
                countAF = result.getInt("COUNT(id)");
            }
            AvailableFolwers.setText(String.valueOf(countAF));
        }catch(Exception e) {e.printStackTrace();}
        
    }
    
    public void homeTI() {
        
        String sql = "SELECT SUM(total) FROM customer_information";
        
        connect = database.connectionDb();
        
        try{
            
            double countTI = 0;
            statement = connect.createStatement();
            result = statement.executeQuery(sql);
            
            if(result.next()){
                countTI = result.getInt("SUM(total)");
            }
            
            TotalIncome.setText("$" + String.valueOf(countTI));
            
        }catch(Exception e) {e.printStackTrace();}
        
    }
    
    public void homeTC() {
        
        String sql = "SELECT COUNT(id) FROM customer_information";
        connect = database.connectionDb();
        
        try{
            
            int countTC = 0;
            
            statement = connect.createStatement();
            result = statement.executeQuery(sql);
            
            if(result.next()){
                countTC = result.getInt("COUNT(id)");
            }
            TotalCustomer.setText(String.valueOf(countTC));
            
        }catch(Exception e){e.printStackTrace();}
    }
    
    public void homeChart() {
        
        home_tableView.getData().clear();
        
        String sql = "SELECT date, SUM(total) FROM customer_information GROUP BY date ORDER BY TIMESTAMP(date) ASC LIMIT 7";
        
        connect = database.connectionDb();
        
        try{
            XYChart.Series chart = new XYChart.Series();
            
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();
            
            while(result.next()) {
               chart.getData().add(new XYChart.Data(result.getString(1), result.getInt(2)));
               
            }
            
            home_tableView.getData().add(chart);
            
        }catch(Exception e) {e.printStackTrace();}
    }
    
    private double totalP = 0;
    
    public void purchasePay() {
        
        String sql = "INSERT INTO customer_information (customer_id, total, date) VALUES(?,?,?)";
        
        connect = database.connectionDb();
        
        try{
            
            Alert alert;
            
            if(totalP == 0) {
                alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Something wrong :3");
                alert.showAndWait();
                
            }else{
                
                alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Message");
                alert.setHeaderText(null);
                alert.setContentText("Are you sure to pay?");
                
               Optional<ButtonType> option = alert.showAndWait();
               
               if(option.get().equals(ButtonType.OK)){
                    prepare = connect.prepareStatement(sql);
                    prepare.setString(1, String.valueOf(customerId));
                    prepare.setString(2, String.valueOf(totalP));
                   

                    Date date = new Date();
                    java.sql.Date sqlDate = new java.sql.Date(date.getTime());

                    prepare.setString(3, String.valueOf(sqlDate));

                    prepare.executeUpdate();
                    
                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Infformation Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Successful !! Thanks for purchased!");
                    alert.showAndWait();
                    totalP = 0; 
               }
            }
        }catch(Exception e) {e.printStackTrace();} 
        }
    
    public void purchaseDisplayTotal() {
        purchaseCustomerId();
        
        String sql = "SELECT SUM(price) FROM customer WHERE customer_id = '"
                + customerId + "'";
        
        connect = database.connectionDb();
        
        try{
            
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();
            
            if(result.next()){
                totalP = result.getDouble("SUM(price)");
            }
            
            Purchase_total.setText("$" + String.valueOf(totalP));
            
            
        }catch (Exception e) {e.printStackTrace();}
        
    }
     
    public void switchForm(ActionEvent event) {

        if (event.getSource() == homeBtn) {
            home_form.setVisible(true);
            available_form.setVisible(false);
            purchase_form.setVisible(false);
            

            homeBtn.setStyle("-fx-background-color:#ae2d3c;");
            AvailableFlowersBtn.setStyle("-fx-background-color:transparent");
            PurchaseBtn.setStyle("-fx-background-color:transparent");
            
            homeTC();
            homeTI();
            homeAF();
            homeChart();

//            displayTotalSoldTicket();
//            displayTotalIncomeToday();
//            displaytotalAvailableMovies();
//            slider();
            
        } else if (event.getSource() == AvailableFlowersBtn) {
            available_form.setVisible(true);
            home_form.setVisible(false);
            purchase_form.setVisible(false);
            

//            showAddMoviesList();
            
            AvailableFlowersBtn.setStyle("-fx-background-color:#ae2d3c;");
            homeBtn.setStyle("-fx-background-color:transparent");
            PurchaseBtn.setStyle("-fx-background-color:transparent");
            
            availableFlowerShowListData();
            availableFlowersStatus();
            availableFlowersSearch();
            
            
        } else if (event.getSource() == PurchaseBtn) {
            available_form.setVisible(false);
            home_form.setVisible(false);
            purchase_form.setVisible(true);
            
//            showAvailableMovies();
                purchaseShowListData();
                purchaseFlowerId();
                purchaseFlowerName();
                purchaseSpinner();
                purchaseDisplayTotal();
            PurchaseBtn.setStyle("-fx-background-color:#ae2d3c;");
            homeBtn.setStyle("-fx-background-color:transparent");
            AvailableFlowersBtn.setStyle("-fx-background-color:transparent");

        }

    }   
    public void purchaseFlowerId() {
         
         String sql = "SELECT status, flower_id FROM flowers WHERE status = 'Available'";
         
         connect = database.connectionDb();
         
         try{
             
             ObservableList listData = FXCollections.observableArrayList();
             
             prepare = connect.prepareStatement(sql);
             result = prepare.executeQuery();
             
             while(result.next()) {
                 listData.add(result.getInt("flower_id"));
             }
             Purchase_flowerID.setItems(listData);
             
             purchaseFlowerName();
             
         }catch(Exception e) {e.printStackTrace();}
         
     }
    public void purchaseFlowerName() {
         
         String sql = "SELECT flower_id, name FROM flowers WHERE flower_id = '"
                + Purchase_flowerID.getSelectionModel().getSelectedItem() + "'";
         
         connect = database.connectionDb();
         
         try{
                prepare = connect.prepareStatement(sql);
                result = prepare.executeQuery();
                
                ObservableList listData = FXCollections.observableArrayList();
  
             while(result.next()) {
                 listData.add(result.getString("name"));
             }
             Purchase_flowerName.setItems(listData);
             
             
         }catch(Exception e) {e.printStackTrace();}
         
    }
    
    private SpinnerValueFactory<Integer> spinner;
    public void purchaseSpinner() {
        
        spinner = new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 10, 0);
        Purchase_quantity.setValueFactory(spinner);
        
    }
     
    private int qty;
    public void purchaseQuantity() {
        qty = Purchase_quantity.getValue();
    }
     
    @Override
    public void initialize(URL location, ResourceBundle resources) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    
    displayUsername();
    availableFlowerShowListData();
    availableFlowersStatus();
    availableFlowersSearch();
    
    purchaseShowListData();
    purchaseFlowerId();
    purchaseFlowerName();
    purchaseSpinner();
    purchaseDisplayTotal();
    
    homeTC();
    homeTI();
    homeAF();
    homeChart();
    
    }
    
}
