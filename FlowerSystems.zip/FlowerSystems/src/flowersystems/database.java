/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flowersystems;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Vannchinhkuy
 */
public class database {
    
    public static Connection connectionDb() {
        try{
            
            Class.forName("com.mysql.jdbc.Driver");
            // Connection connect = DriverManager.getConnection("jdbc:mysql://localhost/(Name Of Database)", "(Username of your database) THE COMMON USERNAME OF DATABASE IS ROOT", "Password of your database THE COMMON PASSWORD OF DATABASE IS");
            // DATABASE NAEM = moviebook
            Connection connect = DriverManager.getConnection("Jdbc:mysql://localhost/flower", "root", "");
            return connect;
        }catch(Exception e) {e.printStackTrace();}
        return null;
    }
        
}    
 
    
    

