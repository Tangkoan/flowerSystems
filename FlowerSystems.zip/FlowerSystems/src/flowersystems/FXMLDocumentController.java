/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flowersystems;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author Vannchinhkuy
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    @FXML
    private Button close;

    @FXML
    private Button login_Btn;

    @FXML
    private PasswordField password;

    @FXML
    private TextField username;
    private Connection connect;
    private ResultSet result;
    private PreparedStatement prepare;
        
        private double x = 0;
        private double y = 0;
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        
    }
     public void close() {
        System.exit(0);
    }
     
             public void Login(){
            
            String adminData ="SELECT * FROM adminflower WHERE username = ? and password = ?";
            
            connect = database.connectionDb();
            
            try {
                
                Alert alert;
                
                //  CHECK IF THE TEXTFIELDS ARE EMPTY OR
                
                if(username.getText().isEmpty()
                        || password.getText().isEmpty()){
                        alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Error Message");
                        alert.setHeaderText(null);
                        alert.setContentText("Please fill all blank fields");
                        alert.showAndWait();   
                        // LETS TRY BUT FIRST WE NEED TO INSERT THE DATA FIRST
                }else{
                    prepare = connect.prepareStatement(adminData);
                    prepare.setString(1, username.getText());
                    prepare.setString(2, password.getText());
                    result = prepare.executeQuery();
                    
                    if(result.next()) {
                        // THE LETS PROCEED TO DASHBOARD FORM LETS CREATE DASHBOARD FORM FOR ADMIN : )
                        // HIDE LOGIN FORM :)
                        
                        getData.username = username.getText();
                        
                        alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Information Message");
                        alert.setHeaderText(null);
                        alert.setContentText("Successfully Login!");
                        alert.showAndWait();
                        
                        login_Btn.getScene().getWindow().hide();
                                
                        Parent root = FXMLLoader.load(getClass().getResource("dashboard.fxml"));
                        
                        Stage stage = new Stage();
                        Scene scene = new Scene(root);
                        
                        root.setOnMousePressed((MouseEvent event) ->{
                            x = event.getSceneX();
                            y = event.getSceneY();
                        });
                        
                        root.setOnMouseDragged((MouseEvent event) ->{
                            stage.setX(event.getScreenX() - x);
                            stage.setY(event.getScreenY() - y);
                        });
                        
                        stage.initStyle(StageStyle.TRANSPARENT);
                        
                        stage.setScene(scene);
                        stage.show();
                    
                    
                    }else{
                        // IF WRONG DATA YOU GAVE THEN ERROR MESSAGE
                        alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Error Message");
                        alert.setHeaderText(null);
                        alert.setContentText("Wrong Username/Password");
                        alert.showAndWait();       
                    }
                }
                
            }catch(Exception e) {e.printStackTrace();}
            
            
        }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
